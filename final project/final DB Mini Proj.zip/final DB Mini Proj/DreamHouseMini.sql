Create database DreamHouseMini;
use DreamHouseMini;
-- drop database DreamHouseMini;
Create table Branches
(
	Branch_number varchar(55),
    Branch_name varchar(100),
    Branch_address varchar(255),
    Branch_city varchar(255),
    Branch_tel numeric(10),
    primary key(Branch_number)
);


Create table Staff
(
    Staff_number varchar(55) not null,
    Full_name varchar(55) not null,
    Sex Varchar(10) not null,
    DOB date not null,
    Staff_position varchar(55) not null,
    Staff_salary numeric(55) not null,
    Staff_hired_date date not null,
    Staff_bonus_pay numeric(55),
    Staff_supervisor_name varchar(55) not null,
    Branch_number varchar(55) not null,
    primary key(Staff_number),
    foreign key(Branch_number) references Branches(Branch_number) on delete cascade
);

Create table Properties
(
	Property_number varchar(55) not null,
    Property_type varchar(55) not null,
    Property_address varchar(255) not null,
    Property_rent numeric(10) not null,
    Property_room numeric(10) not null,
    Staff_number varchar(55) not null,
    Property_deposit numeric(55) not null,
    Branch_number varchar(55) not null,
    primary key(Property_number),
    foreign key(Branch_number) references Branches(Branch_number) on delete cascade,
    foreign key(Staff_number) references Staff(Staff_number) on delete cascade
);

create table Powner
(
	Powner_name varchar(55) not null,
    Powner_number varchar(55) not null,
    Powner_address varchar(255) not null,
    Powner_tel_no numeric(10) not null,
    Powner_type varchar(55) not null,
    Property_number varchar(55) not null,
    primary key(Powner_number),
    foreign key(Property_number) references Properties(Property_number) on delete cascade
);

Create table Clients
(
	Client_number varchar(55) not null,
    Client_name varchar(55) not null,
    Client_pro_type varchar(55) not null,
    Client_tel_no numeric(10) not null,
    Client_max_rent numeric(10) not null,
    Branch_number varchar(55) not null,
    Staff_number varchar(55) not null,
    Client_reg_date date not null,
    Branch_address varchar(255) not null,
    primary key(Client_number),
    foreign key(Branch_number) references Branches(Branch_number) on delete cascade,
    foreign key(Staff_number) references Staff(Staff_number)on delete cascade
);

Create table Pview
(
	Property_number varchar(55) not null,
    Client_number varchar(55) not null,
    Property_type varchar(55) not null,
    Property_view_date date not null,
    Property_address varchar(255) not null,
    Property_comment varchar(255),
    foreign key(Property_number) references Properties(Property_number) on delete cascade,
    foreign key(Client_number) references Clients(Client_number) on delete cascade
);

CREATE TABLE Lease (
    Client_number varchar(55) not null,
    Property_number varchar(55) not null,
    Client_name varchar(55) not null,
    Property_address varchar(255) not null,
    Lease_rent numeric(10) not null,
    Lease_deposit_paid varchar(10) not null,
    Lease_s_date date not null,
    Lease_e_date date not null,
    Payment_method varchar(55),
    Lease_duration int as (DATEDIFF(Lease_e_date, Lease_s_date) div 30) virtual,
    primary key (Property_number),
    foreign key(Client_number) references Clients(Client_number) on delete cascade,
    foreign key(Property_number) references Properties(Property_number) on delete cascade
);

Create table Advertisements
(
	Advertisement_id int not null,
    Property_number varchar(55) not null,
    Advertisement_date date not null,
    primary key(Advertisement_id),
    foreign key(Property_number) references Properties(Property_number) on delete cascade
);


INSERT INTO Branches (Branch_number, Branch_name, Branch_address, Branch_city, Branch_tel) VALUES
('B001', 'Main Branch', '123 Main St', 'New York', 1234567890),
('B002', 'Downtown Branch', '456 Elm St', 'Los Angeles', 2345678901),
('B003', 'North Branch', '789 Oak St', 'London', 3456789012),
('B004', 'South Branch', '987 Glasgow St', 'Glasgow', 4567890123),
('B005', 'East Branch', '654 Maple St', 'Glasgow', 5678901234),
('B006', 'West Branch', '321 Cedar St', 'San Francisco', 6789012345);

INSERT INTO Staff (Staff_number, Full_name, Sex, DOB, Staff_position, Staff_salary, Staff_hired_date, Staff_bonus_pay, Staff_supervisor_name, Branch_number) VALUES
('S001', 'John Doe', 'Male', '1980-01-01', 'Manager', 100000, '2010-01-01', 10000, 'Jane Smith', 'B001'),
('S002', 'Jane Smith', 'Female', '1985-05-05', 'Assistant Manager', 80000, '2012-01-01', 5000, 'John Doe', 'B001'),
('S003', 'Bob Johnson', 'Male', '1990-10-10', 'Clerk', 50000, '2015-01-01', null, 'Jane Smith', 'B002'),
('S004', 'Alice Lee', 'Female', '1995-03-15', 'Assistant', 50000, '2017-01-01', null, 'John Doe', 'B003'),
('S005', 'Mark Davis', 'Male', '1988-08-20', 'Clerk', 55000, '2018-01-01', null, 'Jane Smith', 'B004'),
('S006', 'Emily Chen', 'Female', '1992-11-25', 'Clerk', 55000, '2019-01-01', null, 'John Doe', 'B005');

INSERT INTO Properties (Property_number, Property_type, Property_address, Property_rent, Property_room, Staff_number, Property_deposit, Branch_number) VALUES
('P001', 'Apartment', '123 Glasgow St, Apt 1A', 200, 2, 'S001', 5000, 'B001'),
('P002', 'House', '456 Elm St', 3000, 3, 'S002', 8000, 'B001'),
('P003', 'Flat', '789 Oak St, Unit 5B', 2500, 2, 'S003', 6000, 'B002'),
('P004', 'Townhouse', '987 Glasgow St', 350, 4, 'S004', 10000, 'B003'),
('P005', 'Apartment', '654 Glasgow St, Apt 2C', 2200, 2, 'S005', 5500, 'B004'),
('P006', 'House', '321 Cedar St', 2800, 3, 'S006', 7000, 'B005'),
('P007', 'Flat', '321 Aberdeen St', 450, 7, 'S006', 7500, 'B005');

INSERT INTO Powner (Powner_name, Powner_number, Powner_address, Powner_tel_no, Powner_type, Property_number) VALUES
('John Smith', 'PO001', '456 Elm St', 5551234, 'Private', 'P002'),
('Riddhish Mahajan', 'PO002', '789 Oak St, Unit 5B', 5555678, 'Business', 'P003'),
('Acme Corporation', 'PO003', '123 Main St', 5559999, 'Corporate', 'P001'),
('XYZ LLC', 'PO004', '987 Pine St', 5554321, 'Corporate', 'P004'),
('Johnson and sons', 'PO005', '654 Maple St, Apt 2C', 5556789, 'Business', 'P005'),
('Alice Williams', 'PO006', '321 Cedar St', 5552468, 'Individual', 'P006');

INSERT INTO Clients (Client_number, Client_name, Client_pro_type, Client_tel_no, Client_max_rent, Branch_number, Staff_number, Client_reg_date, Branch_address) VALUES
('C001', 'Hary Smith', 'Apartment', 5551234, 2000, 'B001', 'S001', '2022-01-15', '123 Main St'),
('C002', 'Hemant Doe', 'House', 5555678, 5000, 'B002', 'S002', '2022-02-20', '456 Elm St'),
('C003', 'Samer Kumar', 'Flat', 5559999, 10000, 'B001', 'S003', '2022-03-01', '123 Main St'),
('C004', 'XYZ LLC', 'Townhouse', 5554321, 3500, 'B003', 'S004', '2022-04-10', '789 Oak St'),
('C005', 'Sam Johnson', 'Apartment', 5556789, 3000, 'B002', 'S005', '2022-01-05', '456 Elm St'),
('C006', 'Alice Williams', 'Flat', 5552468, 8000, 'B001', 'S006', '2022-06-30', '123 Main St');

INSERT INTO Pview (Property_number, Client_number, Property_type, Property_view_date, Property_address, Property_comment)
VALUES ('P001', 'C001', 'Apartment', '2022-01-01', '123 Glasgow St, Apt 1A', 'Nice place with great view'),
       ('P002', 'C002', 'House', '2022-02-15', '456 Elm St', 'Needs some updates, but good potential'),
       ('P003', 'C003', 'Flat', '2022-03-20', '789 Oak St, Unit 5B', 'Small but cozy'),
       ('P004', 'C004', 'Townhouse', '2022-04-10', '987 Glasgow St', 'Spacious with lots of natural light'),
       ('P005', 'C005', 'Apartment', '2022-05-05', '654 Glasgow St, Apt 2C', 'Great location near downtown'),
		('P006', 'C003', 'House', '2021-08-05', 'Delhi', '');
       
INSERT INTO Lease (Client_number, Property_number, Client_name, Property_address, Lease_rent, Lease_deposit_paid, Lease_s_date, Lease_e_date, Payment_method)
VALUES
('C001', 'P001', 'Hary Smith', '123 Main St', 1200, 'Yes', '2022-01-01', '2023-01-01', 'Credit Card'),
('C002', 'P002', 'Hemant Doe', '456 Elm st', 1500, 'No', '2022-02-01', '2023-01-01', 'Bank Transfer'),
('C003', 'P003', 'Samer Kumar', '789 Oak St, Unit 5B', 1800, 'Yes', '2022-03-01', '2023-01-01', 'Cash'),
('C004', 'P004', 'XYZ LLC', '987 Pine St', 2000, 'No', '2022-04-01', '2023-04-01', 'Cheque'),
('C005', 'P006', 'XYZ LLC', '654 Glasgow St, Apt 2C', 2200, 'No', '2022-04-20', '2023-04-25', 'Cheque');

INSERT INTO Advertisements (Advertisement_id, Property_number, Advertisement_date) VALUES
(1, 'P001', '2022-01-01'),
(2, 'P001', '2022-01-03'),
(3, 'P001', '2022-01-05'),
(4, 'P002', '2022-01-07'),
(5, 'P003', '2022-01-09'),
(6, 'P004', '2022-01-09'),
(7, 'P005', '2022-01-09');


-- 1 List details of staff supervised by a named Supervisor at the branch.
Select * from staff where staff_supervisor_name = "John Doe" and Branch_number = "B001";

-- 2 List details of all Assistants alphabetically by name at the branch.
SELECT *
FROM Staff
WHERE Staff_position = 'Assistant' AND Branch_number = 'B003'
ORDER BY Full_name ASC;

-- List the details of property (including the rental deposit) available for rent at the branch, along with the owner’s details.
SELECT 
  p.Property_number, 
  p.Property_type, 
  p.Property_address, 
  p.Property_rent, 
  p.Property_room, 
  po.Powner_name, 
  po.Powner_address, 
  po.Powner_tel_no,
  p.Property_deposit
FROM 
  Properties p 
  JOIN Powner po ON p.Property_number = po.Property_number
  JOIN Branches b ON p.Branch_number = b.Branch_number
WHERE 
  p.Branch_number = 'B001' AND p.Property_rent > 0;

-- List the details of properties managed by a named member of staff at the branch.
Select Properties.* , Powner.* from Properties 
join Powner on Properties.Property_number = Powner.Property_number 
where Properties.Staff_number = "S002" and Properties.Branch_number = "B001";

-- List the clients registering at the branch and the names of the members of staff who registered the clients.
SELECT c.Client_number, c.Client_name, c.Client_reg_date, s.Full_name AS Staff_name
FROM Clients c
JOIN Staff s ON c.Staff_number = s.Staff_number
WHERE c.Branch_number = 'B001';

-- Select C.* , S.Full_name from Staff S , Clients C Where C.Staff_number = S.Staff_number and C.branch_number = 'B001';
--  Identify properties located in Glasgow with rents no higher than £450.
SELECT Property_number, Property_type, Property_address, Property_rent
FROM Properties
WHERE Property_address LIKE '%Glasgow%' AND Property_rent <= 450;

-- Identify the name and telephone number of an owner of a given property.
SELECT Powner_name, Powner_tel_no
FROM Powner
WHERE Property_number = 'P001';

-- List the details of comments made by clients viewing a given property.
SELECT Property_comment , Property_number
FROM Pview
WHERE Property_number = 'P001' AND Property_comment IS NOT NULL;

-- Display the names and phone numbers of clients who have viewed a given property but not supplied comments.
SELECT Clients.Client_tel_no ,Clients.Client_name
FROM Clients
INNER JOIN Pview ON Clients.Client_number = Pview.Client_number
WHERE Pview.Property_number = 'P001' AND Pview.Property_comment IS NULL;

-- Display the details of a lease between a named client and a given property.
SELECT *
FROM Lease
WHERE Client_name = 'Hary Smith'
  AND Property_number = 'P001';

--  Identify the leases due to expire next month at the branch.

SELECT *
FROM Lease
WHERE DATE_ADD(Lease_e_date, INTERVAL 1 MONTH) >= NOW()
AND DATE_ADD(Lease_e_date, INTERVAL 1 MONTH) < DATE_ADD(NOW(), INTERVAL 1 MONTH);

-- List the details of properties that have not been rented out for more than three months.
-- SELECT p.*
-- FROM Properties p
-- LEFT JOIN Lease l ON p.Property_number = l.Property_number AND l.Lease_e_date <= DATE_SUB(CURDATE(), INTERVAL 3 MONTH);

-- Select * from Lease;
-- Change This Query
Select Properties.* from Properties , Lease where Properties.Property_number = Lease.Property_number and Lease_duration < 3;

--  Produce a list of clients whose preferences match a particular property.
SELECT DISTINCT c.Client_number, c.Client_name, c.Client_pro_type, c.Client_max_rent
FROM Clients c
INNER JOIN Properties p ON c.Branch_number = p.Branch_number
WHERE p.Property_type = 'Apartment' AND p.Property_rent <= 2000;

-- heck


-- (a) List the details of branches in a given city.
SELECT * FROM Branches WHERE Branch_city = 'Glasgow';

-- (b) Identify the total number of branches in each city.
SELECT Branch_city, COUNT(*) as Total_Branches FROM Branches GROUP BY Branch_city;

-- (c) List the name, position, and salary of staff at a given branch, ordered by staff name.
SELECT Full_name, Staff_position, Staff_salary FROM Staff WHERE Branch_number = 'B001' ORDER BY Full_name;

-- (d) Identify the total number of staff and the sum of their salaries.
SELECT COUNT(*) as Total_Staff, SUM(Staff_salary) as Total_Salary FROM Staff;

-- (e) Identify the total number of staff in each position at branches in Glasgow.
SELECT Staff_position, COUNT(*) as Total_Staff FROM Staff
INNER JOIN Branches ON Staff.Branch_number = Branches.Branch_number
WHERE Branches.Branch_city = 'Glasgow'
GROUP BY Staff_position;

-- (f) List the name of each Manager at each branch, ordered by branch address.
SELECT Branch_address, Full_name as Manager_Name FROM Staff
INNER JOIN Branches ON Staff.Branch_number = Branches.Branch_number
WHERE Staff_position like '%Manager%'
ORDER BY Branch_address;

-- (g) List the names of staff supervised by a named Supervisor.
SELECT Full_name FROM Staff
WHERE Staff_supervisor_name = 'John Smith';

-- (h) List the property number, address, type, and rent of all properties in Glasgow, ordered by rental amount.
SELECT Property_number, Property_address, Property_type, Property_rent
FROM Properties
WHERE Property_address like '%Glasgow%'
ORDER BY Property_rent;

-- (i) List the details of properties for rent managed by a named member of staff.
SELECT *
FROM Properties
WHERE Staff_number = (SELECT Staff_number FROM Staff WHERE Full_name = 'John Doe');

-- (j) Identify the total number of properties assigned to each member of staff at a given branch.
SELECT s.Staff_number, s.Full_name AS Staff_Name, COUNT(*) AS Total_properties
FROM Staff s
JOIN Properties p ON s.Staff_number = p.Staff_number
WHERE p.Branch_number = 'B001'
GROUP BY s.Staff_number;

-- (k) List the details of properties provided by business owners at a given branch.
SELECT Properties.Property_number, Properties.Property_type, Properties.Property_address, Properties.Property_rent, Powner.Powner_name, Powner.Powner_address, Powner.Powner_tel_no
FROM Properties
JOIN Powner ON Properties.Property_number = Powner.Property_number
JOIN Branches ON Properties.Branch_number = Branches.Branch_number
WHERE Branches.Branch_name = 'Downtown Branch' and Powner.Powner_type = 'Business';

-- (l) Identify the total number of properties of each type at all branches.
SELECT Property_type, COUNT(*) as Total_properties
FROM Properties
GROUP BY Property_type;

-- (m) Identify the details of private property owners that provide more than one property for rent.
SELECT Powner_number, Powner_name, Powner_address, Powner_tel_no, COUNT(*) as Total_properties
FROM Powner
INNER JOIN Properties ON Powner.Property_number = Properties.Property_number
WHERE Powner.Powner_type = 'Private'
GROUP BY Powner.Powner_number
HAVING COUNT(*) > 1;

-- (n) Identify flats with at least three rooms and with a monthly rent no higher than £500 in Aberdeen.
SELECT *
FROM Properties
WHERE Property_type = 'Flat' AND Property_room >= 3 AND Property_rent <= 500 AND Property_address LIKE '%Aberdeen%';

-- (o) List the number, name, and telephone number of clients and their property preferences at a given branch.
SELECT Client_number, Client_name, Client_tel_no, Client_pro_type, Client_max_rent
FROM Clients
WHERE Branch_number = 'B001';

-- (p) Identify the properties that have been advertised more than the average number of times.
SELECT Properties.Property_number, COUNT(*) AS num_advertisements
FROM Properties
JOIN Advertisements ON Properties.Property_number = Advertisements.Property_number
GROUP BY Properties.Property_number
HAVING COUNT(*) > (SELECT AVG(num_advertisements) FROM (SELECT COUNT(*) AS num_advertisements FROM Advertisements GROUP BY Property_number) AS t);


-- (q) List the details of leases due to expire next month at a given branch.
-- SELECT l.Client_number, l.Property_number, c.Client_name, p.Property_address, l.Lease_rent, l.Lease_deposit_paid, l.Lease_s_date, l.Lease_e_date, l.Payment_method
-- FROM Lease AS l
-- JOIN Clients AS c ON l.Client_number = c.Client_number
-- JOIN Properties AS p ON l.Property_number = p.Property_number
-- WHERE MONTH(l.Lease_e_date) = MONTH(DATE_ADD(CURRENT_DATE(), INTERVAL 1 MONTH))
--   AND YEAR(l.Lease_e_date) = YEAR(CURRENT_DATE())
--   AND p.Branch_number = 'B001';

-- SELECT *
-- FROM Lease
-- WHERE Property_number IN (
--   SELECT Property_number
--   FROM Properties
--   WHERE Branch_number = 'B001'
-- ) AND MONTH(Lease_e_date) = MONTH(DATE_ADD(CURDATE(), INTERVAL 1 MONTH))
--    AND YEAR(Lease_e_date) = YEAR(DATE_ADD(CURDATE(), INTERVAL 1 MONTH));

SELECT *
FROM Lease
WHERE DATE_ADD(Lease_e_date, INTERVAL 1 MONTH) >= NOW()
AND DATE_ADD(Lease_e_date, INTERVAL 1 MONTH) < DATE_ADD(NOW(), INTERVAL 1 MONTH);

-- (r) List the total number of leases with rental periods that are less than one year at branches in London.
SELECT COUNT(*) AS Total_Leases
FROM Lease AS l
JOIN Properties AS p ON l.Property_number = p.Property_number
JOIN Branches AS b ON p.Branch_number = b.Branch_number
WHERE DATEDIFF(l.Lease_e_date, l.Lease_s_date) < 365
  AND b.Branch_city = 'London';
  

-- (s) List the total possible daily rental for property at each branch, ordered by branch number.
SELECT p.Branch_number, SUM(p.Property_rent * 12 / 365) AS Total_Daily_Rental
FROM Properties AS p
GROUP BY p.Branch_number
ORDER BY p.Branch_number;


SELECT Lease.*
FROM Lease
INNER JOIN Properties ON Lease.Property_number = Properties.Property_number
INNER JOIN Branches ON Properties.Branch_number = Branches.Branch_number
WHERE MONTH(Lease_e_date) = MONTH(DATE_ADD(CURRENT_DATE, INTERVAL 1 MONTH))
AND YEAR(Lease_e_date) = YEAR(DATE_ADD(CURRENT_DATE, INTERVAL 1 MONTH))
AND Branches.Branch_name = 'B001';

SELECT Client_name, Client_tel_no 
FROM clients 
WHERE client_number IN (
  SELECT client_number 
  FROM pview 
  WHERE Property_comment = ""
);

  SELECT Lease.*
FROM Lease
INNER JOIN Properties ON Lease.Property_number = Properties.Property_number
INNER JOIN Branches ON Properties.Branch_number = Branches.Branch_number
WHERE MONTH(Lease_e_date) = MONTH(DATE_ADD(CURRENT_DATE, INTERVAL 1 MONTH))
AND YEAR(Lease_e_date) = YEAR(DATE_ADD(CURRENT_DATE, INTERVAL 1 MONTH))
AND Branches.Branch_number = 'B006';