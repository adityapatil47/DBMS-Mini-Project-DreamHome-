Create database DreamHome;
 -- drop database DreamHome; 
use DreamHome;

Create table Branches
(
	Branch_number varchar(55),
    Branch_address varchar(255),
    Branch_tel numeric(10),
    primary key(Branch_number)
);
Create table Staff
(
    Staff_number varchar(55) not null,
    Full_name varchar(55) not null,
    Sex Varchar(10) not null,
    DOB date not null,
    Staff_position varchar(55) not null,
    Staff_salary numeric(55) not null,
    Staff_hired_date date not null,
    Staff_bonus_pay numeric(55) ,
    Staff_supervisor_name varchar(55) not null,
    Branch_number varchar(55) not null,
    primary key(Staff_number),
    foreign key(Branch_number) references Branches(Branch_number)
);


Create table Properties
(
	Property_number varchar(55) not null,
    Property_type varchar(55) not null,
    Property_address varchar(255) not null,
    Property_rent numeric(10) not null,
    Property_room numeric(10) not null,
    Staff_number varchar(55) not null,
    Branch_number varchar(55) not null,
    primary key(Property_number),
    foreign key(Branch_number) references Branches(Branch_number),
    foreign key(Staff_number) references Staff(Staff_number)
);

create table Powner
(
	Powner_name varchar(55) not null,
    Powner_number varchar(55) not null,
    Powner_address varchar(255) not null,
    Powner_tel_no numeric(10) not null,
    Property_type varchar(55) not null,
    Property_number varchar(55) not null,
    primary key(Powner_number),
    foreign key(Property_number) references Properties(Property_number)
);

Create table Clients
(
	Client_number varchar(55) not null,
    Client_name varchar(55) not null,
    Client_pro_type varchar(55) not null,
    Client_max_rent numeric(10) not null,
    Branch_number varchar(55) not null,
    Staff_number varchar(55) not null,
    Client_reg_date date not null,
    Branch_address varchar(255) not null,
    primary key(Client_number),
    foreign key(Branch_number) references Branches(Branch_number),
    foreign key(Staff_number) references Staff(Staff_number)
);

Create table Pview
(
	Property_number varchar(55) not null,
    Client_number varchar(55) not null,
    Property_type varchar(55) not null,
    Property_view_date date not null,
    Property_address varchar(255) not null,
    Property_comment varchar(255),
    foreign key(Property_number) references Properties(Property_number),
    foreign key(Client_number) references Clients(Client_number)
);

create table Lease
(
	Client_number varchar(55) not null,
    Property_number varchar(55) not null,
    Client_name varchar(55) not null,
    Property_address varchar(255) not null,
    Lease_rent numeric(10) not null,
    Lease_deposit_paid varchar(10) not null,
    Lease_s_date date not null,
    Lease_e_date date not null,
    Lease_duration numeric(10) not null,
    Payment_method varchar(55),
    foreign key(Client_number) references Clients(Client_number),
    foreign key(Property_number) references Properties(Property_number)
);
INSERT INTO Branches
VALUES ('B001', '123 Main St, Anytown', 5551234);

INSERT INTO Branches
VALUES ('B002', '456 High St, Somewhere', 5555678);

INSERT INTO Branches
VALUES ('B003', '789 Park Ave, Anywhere', 5559101);
/*----------------------------------------------------------------------------------------------------------------------------------------------------------------------------*/

INSERT INTO Staff
VALUES ('S001', 'John Smith', 'Male', '1985-07-15', 'Sales Manager', 50000, '2010-01-01', 5000, 'Emily Brown', 'B001');

INSERT INTO Staff
VALUES ('S002', 'Jane Doe', 'Female', '1990-03-21', 'Marketing Executive', 35000, '2015-05-01', NULL, 'John Smith', 'B001');

INSERT INTO staff (Staff_number, Full_name, Sex, DOB, Staff_position, Staff_salary, Staff_hired_date, Staff_bonus_pay, Staff_supervisor_name, Branch_number)
VALUES ('S003', 'David Lee', 'Male', '1988-11-12', 'Accountant', 45000, '2012-06-01', 2000, 'Emily Brown', 'B002');

INSERT INTO staff (Staff_number, Full_name, Sex, DOB, Staff_position, Staff_salary, Staff_hired_date, Staff_bonus_pay, Staff_supervisor_name, Branch_number)
VALUES ('S004', 'Anna Kim', 'Female', '1993-02-28', 'HR Manager', 55000, '2014-03-01', 8000, 'John Smith', 'B003');

INSERT INTO staff (Staff_number, Full_name, Sex, DOB, Staff_position, Staff_salary, Staff_hired_date, Staff_bonus_pay, Staff_supervisor_name, Branch_number)
VALUES ('S005', 'Peter Chen', 'Male', '1987-09-03', 'Software Developer', 60000, '2013-07-01', 5000, 'David Lee', 'B002');

INSERT INTO staff (Staff_number, Full_name, Sex, DOB, Staff_position, Staff_salary, Staff_hired_date, Staff_bonus_pay, Staff_supervisor_name, Branch_number)
VALUES ('S007', 'Michael Johnson', 'Male', '1991-08-20', 'Customer Service Representative', 30000, '2016-02-01', NULL, 'Anna Kim', 'B003');

INSERT INTO staff (Staff_number, Full_name, Sex, DOB, Staff_position, Staff_salary, Staff_hired_date, Staff_bonus_pay, Staff_supervisor_name, Branch_number)
VALUES ('S008', 'Catherine Wong', 'Female', '1989-04-17', 'Marketing Coordinator', 40000, '2017-01-01', 3000, 'Jane Doe', 'B001');

/*----------------------------------------------------------------------------------------------------------------------------------------------------------------------------*/


INSERT INTO Properties (Property_number, Property_type, Property_address, Property_rent, Property_room, Staff_number, Branch_number)
VALUES ('P001', 'Apartment', '123 Main St, Anytown', 1200, 2, 'S001', 'B001');

INSERT INTO Properties (Property_number, Property_type, Property_address, Property_rent, Property_room, Staff_number, Branch_number)
VALUES ('P002', 'House', '456 High St, Somewhere', 1800, 3, 'S002', 'B002');

INSERT INTO Properties (Property_number, Property_type, Property_address, Property_rent, Property_room, Staff_number, Branch_number)
VALUES ('P003', 'Condo', '789 Park Ave, Anywhere', 1500, 2, 'S003', 'B003');

-- INSERT INTO Properties (Property_number, Property_type, Property_address, Property_rent, Property_room, Staff_number, Branch_number)
-- VALUES ('P004', 'Anturli', '779 Park Aveue, Anywhere', 1500, 2, 'S004', 'B003');

-- INSERT INTO Properties (Property_number, Property_type, Property_address, Property_rent, Property_room, Staff_number, Branch_number)
-- VALUES ('P005', 'Belaswadi', '799 DenPark Ave, Anywhere', 1000, 2, 'S005', 'B003');
/*----------------------------------------------------------------------------------------------------------------------------------------------------------------------------*/

INSERT INTO Powner
VALUES ('John Doe', 'PO001', '456 Main St, Anytown', 5551234, 'Individual', 'P001');

INSERT INTO Powner 
VALUES ('Jane Smith', 'PO002', '789 Elm St, Somewhere', 5555678, 'Company', 'P002');

INSERT INTO Powner
VALUES ('Bob Johnson', 'PO003', '123 Oak St, Anywhere', 5559012, 'Individual', 'P003');

-- INSERT INTO Powner
-- VALUES ('Bob Clark', 'PO005', '123 Oakstand St, Anywhere', 5509012, 'Individual', 'P004');
/*----------------------------------------------------------------------------------------------------------------------------------------------------------------------------*/

INSERT INTO clients (Client_number, Client_name, Client_pro_type, Client_max_rent, Branch_number, Staff_number, Client_reg_date, Branch_address) VALUES ('C001', 'John Doe', 'Apartment', 1500, 'B001', 'S001', '2022-01-01', '123 Main St');
INSERT INTO clients (Client_number, Client_name, Client_pro_type, Client_max_rent, Branch_number, Staff_number, Client_reg_date, Branch_address) VALUES ('C002', 'Jane Smith', 'House', 2000, 'B002', 'S002', '2022-02-15', '456 Oak St');
INSERT INTO clients (Client_number, Client_name, Client_pro_type, Client_max_rent, Branch_number, Staff_number, Client_reg_date, Branch_address) VALUES ('C003', 'Bob Johnson', 'Condo', 1200, 'B001', 'S003', '2022-03-20', '789 Pine Ave');
INSERT INTO clients (Client_number, Client_name, Client_pro_type, Client_max_rent, Branch_number, Staff_number, Client_reg_date, Branch_address) VALUES ('C004', 'Emily Davis', 'Townhouse', 1800, 'B002', 'S004', '2022-04-10', '1011 Maple St');
INSERT INTO clients (Client_number, Client_name, Client_pro_type, Client_max_rent, Branch_number, Staff_number, Client_reg_date, Branch_address) VALUES ('C005', 'Michael Lee', 'Apartment', 1400, 'B003', 'S005', '2022-05-05', '1213 Elm St');
/*----------------------------------------------------------------------------------------------------------------------------------------------------------------------------*/

INSERT INTO Pview (Property_number, Client_number, Property_type, Property_view_date, Property_address, Property_comment)
VALUES ('P001', 'C001', 'House', '2023-05-15', '123 Main St', 'Lovely backyard'),
('P002', 'C003', 'Apartment', '2023-04-18', '456 Elm St', 'Great natural light'),
('P003', 'C004', 'House', '2023-04-25', '789 Oak St', 'Needs some updates'),
('P003', 'C005', 'Condo', '2023-05-01', '555 Pine St', 'Spacious living room'),
('P001', 'C002', 'Apartment', '2023-04-20', '222 Maple St', 'Recently renovated');
/*----------------------------------------------------------------------------------------------------------------------------------------------------------------------------*/

INSERT INTO Lease (Client_number, Property_number, Client_name, Property_address, Lease_rent, Lease_deposit_paid, Lease_s_date, Lease_e_date, Lease_duration, Payment_method)
VALUES
('C004', 'P001', 'John Doe', '123 Main St', 1500, 'Yes', '2022-05-01', '2023-05-01', 12, 'Credit Card'),
('C002', 'P002', 'Jane Smith', '456 Oak St', 2000, 'No', '2022-06-01', '2024-06-01', 24, 'Check'),
('C001', 'P003', 'Bob Johnson', '789 Elm St', 1800, 'Yes', '2022-07-01', '2023-12-01', 5, 'Bank Transfer')
;
/*----------------------------------------------------------------------------------------------------------------------------------------------------------------------------*/

select * from Staff; 
select * from Lease;
select * from Pview;
select * from Pview;
select * from Powner;
select * from Clients;
select * from Properties;
select * from Branches;