const { Console } = require("console");
const express = require("express");
const mysql = require("mysql2");
const path = require("path");

const app = express();

app.use(express.urlencoded({ extended: false }));
app.use(express.json());

const connection = mysql.createConnection({
  host: "localhost",
  user: "root",
  password: "Aditya",
  database: "DreamHome",
});
app.use("/static", express.static("static")); // for serving static files
app.use(express.urlencoded({ extended: true }));

app.engine("html", require("ejs").renderFile);
app.set("view engine", "html");

const static_path = path.join(__dirname, "/views");
app.use(express.static(static_path));
app.set("views", path.join(__dirname, "/views"));

connection.connect((err) => {
  if (err) {
    console.log("Error connecting to database:", err);
    return;
  }

  console.log("Connected to database");
});

// -----------------------------------PropViewReport--------------------------------------------
app.get("/PropViewReport", (req, res) => {
  res.status(200).render("PropViewReport.html");
});
app.post("/PropViewReport", (req, res) => {
  const {
    property_number,
    client_number,
    property_type,
    property_view_date,
    property_address,
    property_comment,
  } = req.body;

  const PropReport = `
  INSERT INTO Pview (Property_number, Client_number, Property_type, Property_view_date, Property_address, Property_comment)
  VALUES (?, ?, ?, ?, ?, ?)
  `;
  connection.query(
    PropReport,
    [
      property_number,
      client_number,
      property_type,
      property_view_date,
      property_address,
      property_comment,
    ],
    (err, result) => {
      if (err) {
        console.log("Error inserting data:", err);
        res.status(500).send("Error inserting data into database");
        return;
      }

      // res.status(200).send("Data inserted into database");
      res.redirect("/PropReport");
    }
  );
});

// Set up a route to handle HTTP GET requests to the root URL
app.get("/PropReport", (req, res) => {
  // PropViewInsert the database to retrieve all data from the Pview table
  connection.query("SELECT * FROM Pview ", (error, results, fields) => {
    if (error) throw error;

    // Render an HTML page that displays the data in a table
    let html = "<html><head><title>Property View</title>";
    html +=
      '<link rel="stylesheet" href="../static/pages/style.css"><script src="../static/components/header.js" type="text/javascript" defer></script>';
    html += "</head><body>";
    html +=
      '<div id="navbar" class="page"><header-component></header-component></div><div id="form" class="page"><main>';
    html += "<h1 id='heading'>Property View</h1><table>";
    html +=
      "<tr><th>Property Number</th><th>Client Number</th><th>Property Type</th><th>Property View Date</th><th>Property Address</th><th>Property Comment</th></tr>";
    for (let i = 0; i < results.length; i++) {
      html += `<tr><td>${results[i].Property_number}</td><td>${results[i].Client_number}</td><td>${results[i].Property_type}</td><td>${results[i].Property_view_date}</td><td>${results[i].Property_address}</td><td>${results[i].Property_comment}</td></tr>`;
    }
    html += "</table></body></html>";

    // Send the HTML page to the client
    res.send(html);
  });
});
// -----------------------------------PropViewReport----end-----------------------------------------
// -----------------------------------ClientReg----start----------------------------------------
// Set up a route to handle HTTP GET requests to the ClientReg page
app.get("/ClientReg", (req, res) => {
  res.status(200).render("ClientReg.html");
});

// Set up a route to handle HTTP POST requests to the ClientReg page
app.post("/ClientReg", (req, res) => {
  const {
    Client_number,
    Client_name,
    Client_pro_type,
    Client_max_rent,
    Branch_number,
    Staff_number,
    Client_reg_date,
    Branch_address,
  } = req.body;

  const clientRegQuery = `
  INSERT INTO Clients (Client_number, Client_name, Client_pro_type, Client_max_rent, Branch_number, Staff_number, Client_reg_date, Branch_address)
  VALUES (?, ?, ?, ?, ?, ?, ?, ?)
  `;
  connection.query(
    clientRegQuery,
    [
      Client_number,
      Client_name,
      Client_pro_type,
      Client_max_rent,
      Branch_number,
      Staff_number,
      Client_reg_date,
      Branch_address,
    ],
    (err, result) => {
      if (err) {
        console.log("Error inserting data:", err);
        res.status(500).send("Error inserting data into database");
        return;
      }

      // res.status(200).send("Data inserted into database");
      res.redirect("/ClientReport");
    }
  );
});

// Set up a route to handle HTTP GET requests to the ClientReport page
app.get("/ClientReport", (req, res) => {
  // Query the database to retrieve all data from the Client table
  connection.query("SELECT * FROM Clients ", (error, results, fields) => {
    if (error) throw error;
    // // Render an HTML page that displays the data in a table
    let html = "<html><head><title>Client Registration Report</title>";
    html +=
      '<link rel="stylesheet" href="../static/pages/style.css"><script src="../static/components/header.js" type="text/javascript" defer></script>';
    html += "<style>main {max-width: 1000px;}</style>";
    html += "</head><body>";
    html +=
      '<div id="navbar" class="page"><header-component></header-component></div><div id="form" class="page"><main>';
    html += "<h1 id='heading'>Client Registration Report</h1><table>";
    html +=
      "<tr><th>Client Number</th><th>Client Name</th><th>Client Property Type</th><th>Client Maximum Rent</th><th>Branch Number</th><th>Staff Number</th><th>Client Registration Date</th><th>Branch Address</th></tr>";
    for (let i = 0; i < results.length; i++) {
      html += `<tr><td>${results[i].Client_number}</td><td>${results[i].Client_name}</td><td>${results[i].Client_pro_type}</td><td>${results[i].Client_max_rent}</td><td>${results[i].Branch_number}</td><td>${results[i].Staff_number}</td><td>${results[i].Client_reg_date}</td><td>${results[i].Branch_address}</td></tr>`;
    }
    html += "</table></body></html>";

    // Send the HTML page to the client
    res.send(html);
  });
});
// ------------------------------------clientReg-----end----------------------------
// -----------------------------------PropRegForm-----start----------------------------
// Set up a route to handle HTTP GET requests to the PropRegForm page
app.get("/PropRegForm", (req, res) => {
  res.status(200).render("PropRegForm.html");
});

// Set up a route to handle HTTP POST requests to the PropRegForm page
app.post("/PropRegForm", (req, res) => {
  const {
    property_number,
    property_type,
    property_address,
    property_rent,
    property_room,
    staff_number,
    branch_number,
  } = req.body;

  const propRegQuery = `INSERT INTO Properties (property_number, property_type, property_address, property_rent, property_room, staff_number, branch_number) VALUES (?, ?, ?, ?, ?, ?, ?) `;
  connection.query(
    propRegQuery,
    [
      property_number,
      property_type,
      property_address,
      property_rent,
      property_room,
      staff_number,
      branch_number,
    ],
    (err, result) => {
      if (err) {
        console.log("Error inserting data:", err);
        res.status(500).send("Error inserting data into database");
        return;
      }
      // res.status(200).send("Data inserted into database");
      res.redirect("/PropRegReport");
    }
  );
});

// Set up a route to handle HTTP GET requests to the PropRegReport page
app.get("/PropRegReport", (req, res) => {
  // Query the database to retrieve all data from the Property table
  connection.query("SELECT * FROM Properties", (error, results, fields) => {
    if (error) throw error;

    // Render an HTML page that displays the data in a table
    let html = "<html><head><title>Property registration Report</title>";
    html +=
      '<link rel="stylesheet" href="../static/pages/style.css"><script src="../static/components/header.js" type="text/javascript" defer></script>';
    html += "</head><body>";
    html +=
      '<div id="navbar" class="page"><header-component></header-component></div><div id="form" class="page"><main>';
    html += "<h1 id='heading'>Property Report</h1><table>";
    html +=
      "<tr><th>Property Number</th><th>Property Type</th><th>Property Address</th><th>Property Rent</th><th>Property Room</th><th>Staff Number</th><th>Branch Number</th></tr>";
    for (let i = 0; i < results.length; i++) {
      html += `<tr><td>${results[i].Property_number}</td><td>${results[i].Property_type}</td><td>${results[i].Property_address}</td><td>${results[i].Property_rent}</td><td>${results[i].Property_room}</td><td>${results[i].Staff_number}</td><td>${results[i].Branch_number}</td></tr>`;
    }
    html += "</table></body></html>";

    // Send the HTML page to the client
    res.send(html);
  });
});
// -----------------------------------PropRegForm-----end----------------------------
// --------------------------------LeaseForm----start----------------------
app.get("/LeaseForm", (req, res) => {
  res.status(200).render("LeaseForm.html");
});

// Set up a route to handle HTTP POST requests to the form URL
app.post("/LeaseForm", (req, res) => {
  // Extract the submitted data from the request body
  const {
    client_number,
    property_number,
    client_name,
    property_address,
    lease_rent,
    lease_deposit_paid,
    lease_s_date,
    lease_e_date,
    lease_duration,
    payment_method,
  } = req.body;

  // Define a SQL query to insert the data into the database
  const insertQuery = `
    INSERT INTO Lease (client_number, property_number, client_name, property_address, lease_rent, lease_deposit_paid, lease_s_date, lease_e_date, lease_duration, payment_method)
    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
  `;

  // Execute the SQL query with the submitted data
  connection.query(
    insertQuery,
    [
      client_number,
      property_number,
      client_name,
      property_address,
      lease_rent,
      lease_deposit_paid,
      lease_s_date,
      lease_e_date,
      lease_duration,
      payment_method,
    ],
    (error, results, fields) => {
      if (error) {
        console.error("Error inserting data:", error);
        res.status(500).send("Error inserting data into database");
        return;
      }

      // Redirect to the report page
      res.redirect("/LeaseReport");
    }
  );
});

// Set up a route to handle HTTP GET requests to the report URL
app.get("/LeaseReport", (req, res) => {
  // Define a SQL query to select all data from the Lease table
  const selectQuery = "SELECT * FROM Lease";

  // Execute the SQL query
  connection.query(selectQuery, (error, results, fields) => {
    if (error) {
      console.error("Error selecting data:", error);
      res.status(500).send("Error selecting data from database");
      return;
    }

    // Render an HTML page that displays the data in a table
    let html = "<html><head><title>Lease Report</title>";
    html +=
      '<link rel="stylesheet" href="../static/pages/style.css"><script src="../static/components/header.js" type="text/javascript" defer></script>';
    html += "<style>main {max-width: 1000px;}</style>";
    html += "</head><body>";
    html +=
      '<div id="navbar" class="page"><header-component></header-component></div><div id="form" class="page"><main>';
    html += "<h1 id='heading'>Lease Report</h1><table>";
    html +=
      "<tr><th>Client Number</th><th>Property Number</th><th>Client Name</th><th>Property Address</th><th>Lease Rent</th><th>Lease Deposit Paid</th><th>Lease Start Date</th><th>Lease End Date</th><th>Lease Duration</th><th>Payment Method</th></tr>";
    for (let i = 0; i < results.length; i++) {
      html += `<tr><td>${results[i].Client_number}</td><td>${results[i].Property_number}</td><td>${results[i].Client_name}</td><td>${results[i].Property_address}</td><td>${results[i].Lease_rent}</td><td>${results[i].Lease_deposit_paid}</td><td>${results[i].Lease_s_date}</td><td>${results[i].Lease_e_date}</td><td>${results[i].Lease_duration}</td><td>${results[i].Payment_method}</td></tr>`;
    }
    html += "</table></body></html>";

    // Send the HTML page to the client
    res.send(html);
  });
});
// --------------------------------LeaseForm----end----------------------
// --------------------------------Branches----start----------------------
app.get("/BranchForm", (req, res) => {
  res.status(200).render("Branches.html");
});
app.post("/BranchForm", (req, res) => {
  const { Branch_Number, Branch_Address, Branch_Tel } = req.body;

  const branchInsert = `
    INSERT INTO Branches (Branch_Number, Branch_Address, Branch_Tel)
    VALUES (?, ?, ?)
  `;

  connection.query(
    branchInsert,
    [Branch_Number, Branch_Address, Branch_Tel],
    (err, result) => {
      if (err) {
        console.log("Error inserting data:", err);
        res.status(500).send("Error inserting data into database");
        return;
      }
      res.redirect("/BranchList");
    }
  );
});
app.get("/BranchList", (req, res) => {
  const BranchQuery = "SELECT * FROM Branches";
  connection.query(BranchQuery, (error, results, fields) => {
    if (error) throw error;

    let html = "<html><head><title>Branch List</title>";
    html +=
      '<link rel="stylesheet" href="../static/pages/style.css"><script src="../static/components/header.js" type="text/javascript" defer></script>';
    html += "</head><body>";
    html +=
      '<div id="navbar" class="page"><header-component></header-component></div><div id="form" class="page"><main>';
    html += "<h1 id='heading'>Branches</h1><table>";
    html +=
      "<tr><th>Branch Number</th><th>Branch Address</th><th>Branch Telephone</th></tr>";
    for (let i = 0; i < results.length; i++) {
      html += `<tr><td>${results[i].Branch_number}</td><td>${results[i].Branch_address}</td><td>${results[i].Branch_tel}</td></tr>`;
    }
    html += "</table></body></html>";

    res.send(html);
  });
});
// --------------------------------Branches----end----------------------
//--------------------------------PropOweners----start----------------------
// Set up a route to handle HTTP GET requests to the form URL
app.get("/OwnerForm", (req, res) => {
  res.status(200).render("PropOweners.html");
});

// Set up a route to handle HTTP POST requests to the form URL
app.post("/OwnerForm", (req, res) => {
  // Extract the submitted data from the request body
  const {
    Powner_name,
    Powner_number,
    Powner_address,
    Powner_tel_no,
    Property_type,
    Property_number,
  } = req.body;

  // Define a SQL query to insert the data into the database
  const insertQuery = `
    INSERT INTO Powner (Powner_name, Powner_number, Powner_address, Powner_tel_no, Property_type, Property_number)
    VALUES (?, ?, ?, ?, ?, ?)
  `;

  // Execute the SQL query with the submitted data
  connection.query(
    insertQuery,
    [
      Powner_name,
      Powner_number,
      Powner_address,
      Powner_tel_no,
      Property_type,
      Property_number,
    ],
    (error, results, fields) => {
      if (error) {
        console.error("Error inserting data:", error);
        res.status(500).send("Error inserting data into database");
        return;
      }

      // Redirect to the report page
      res.redirect("/OwnerReport");
    }
  );
});

// Set up a route to handle HTTP GET requests to the report URL
app.get("/OwnerReport", (req, res) => {
  // Define a SQL query to select all data from the PropertyOwners table
  const selectQuery = "SELECT * FROM Powner";

  // Execute the SQL query
  connection.query(selectQuery, (error, results, fields) => {
    if (error) {
      console.error("Error selecting data:", error);
      res.status(500).send("Error selecting data from database");
      return;
    }

    // Render an HTML page that displays the data in a table
    let html =
      "<!DOCTYPE html><html><head><title>Property Owner Report</title>";
    html +=
      '<link rel="stylesheet" href="../static/pages/style.css"><script src="../static/components/header.js" type="text/javascript" defer></script>';
    html += "</head><body>";
    html +=
      '<div id="navbar" class="page"><header-component></header-component></div><div id="form" class="page"><main>';
    html += "<h1 id='heading'>Property Owner Report</h1><table>";
    html +=
      "<tr><th>Owner Name</th><th>Owner Number</th><th>Owner Address</th><th>Owner Telephone Number</th><th>Property Type</th><th>Property Number</th></tr>";
    for (let i = 0; i < results.length; i++) {
      html += `<tr><td>${results[i].Powner_name}</td><td>${results[i].Powner_number}</td><td>${results[i].Powner_address}</td><td>${results[i].Powner_tel_no}</td><td>${results[i].Property_type}</td><td>${results[i].Property_number}</td></tr>`;
    }
    html += "</table></main></div></body></html>";

    // Send the HTML page to the client
    res.send(html);
  });
});
//--------------------------------PropOweners----end----------------------
// --------------------------------staffReg----start----------------------
// Set up a route to handle HTTP GET requests to the form URL
app.get("/staffReg", (req, res) => {
  res.status(200).render("StaffRegForm.html");
});

// Set up a route to handle HTTP POST requests to the form URL
app.post("/staffReg", (req, res) => {
  // Extract the submitted data from the request body
  const {
    Staff_number,
    Full_name,
    Sex,
    DOB,
    Staff_position,
    Staff_salary,
    Staff_hired_date,
    Staff_bonus_pay,
    Staff_supervisor_name,
    Branch_number,
  } = req.body;

  // Define a SQL query to insert the data into the database
  const insertQuery = `
    INSERT INTO staff (Staff_number, Full_name, Sex, DOB, Staff_position, Staff_salary, Staff_hired_date, Staff_bonus_pay, Staff_supervisor_name, Branch_number)
    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
  `;

  // Execute the SQL query with the submitted data
  connection.query(
    insertQuery,
    [
      Staff_number,
      Full_name,
      Sex,
      DOB,
      Staff_position,
      Staff_salary,
      Staff_hired_date,
      Staff_bonus_pay,
      Staff_supervisor_name,
      Branch_number,
    ],
    (error, results, fields) => {
      if (error) {
        console.error("Error inserting data:", error);
        res.status(500).send("Error inserting data into database");
        return;
      }

      // Redirect to the report page
      res.redirect("/staffReport");
    }
  );
});

// Set up a route to handle HTTP GET requests to the report URL

app.get("/StaffReport", (req, res) => {
  // Define a SQL query to select all data from the Staff table
  const selectQuery = "SELECT * FROM Staff";

  // Execute the SQL query
  connection.query(selectQuery, (error, results, fields) => {
    if (error) {
      console.error("Error selecting data:", error);
      res.status(500).send("Error selecting data from database");
      return;
    }

    // Render an HTML page that displays the data in a table
    let html = "<!DOCTYPE html><html><head><title>Staff Report</title>";
    html +=
      '<link rel="stylesheet" href="../static/pages/style.css"><script src="../static/components/header.js" type="text/javascript" defer></script>';
    html += "<style>main {max-width: 100%;}</style>";
    html += "</head><body>";
    html +=
      '<div id="navbar" class="page"><header-component></header-component></div><div id="form" class="page"><main>';
    html += "<h1 id='heading'>Staff Report</h1><table>";
    html +=
      "<tr><th>Staff Number</th><th>Full Name</th><th>Sex</th><th>Date of Birth</th><th>Staff Position</th><th>Staff Salary</th><th>Staff Hired Date</th><th>Staff Bonus Pay</th><th>Staff Supervisor Name</th><th>Branch Number</th></tr>";
    for (let i = 0; i < results.length; i++) {
      html += `<tr><td>${results[i].Staff_number}</td><td>${results[i].Full_name}</td><td>${results[i].Sex}</td><td>${results[i].DOB}</td><td>${results[i].Staff_position}</td><td>${results[i].Staff_salary}</td><td>${results[i].Staff_hired_date}</td><td>${results[i].Staff_bonus_pay}</td><td>${results[i].Staff_supervisor_name}</td><td>${results[i].Branch_number}</td></tr>`;
    }
    html += "</table></main></div></body></html>";

    // Send the HTML page to the client
    res.send(html);
  });
});
// --------------------------------staffReg----end----------------------

// --------------------------------testquery----start----------------------

// Set up a route to handle HTTP GET requests to the report URL

app.get("/testQuery", (req, res) => {
  // Define a SQL query to select all data from the Staff table
  const selectQuery = "SELECT * FROM Staff ";

  // Execute the SQL query
  connection.query(selectQuery, (error, results, fields) => {
    if (error) {
      console.error("Error selecting data:", error);
      res.status(500).send("Error selecting data from database");
      return;
    }

    // Render an HTML page that displays the data in a table
    let html = "<!DOCTYPE html><html><head><title>Staff Report</title>";
    html +=
      '<link rel="stylesheet" href="../static/pages/style.css"><script src="../static/components/header.js" type="text/javascript" defer></script>';
    html += "<style>main {max-width: 100%;}</style>";
    html += "</head><body>";
    html +=
      '<div id="navbar" class="page"><header-component></header-component></div><div id="form" class="page"><main>';
    html += "<h1 id='heading'>Staff Report</h1><table>";
    html +=
      "<tr><th>Staff Number</th><th>Full Name</th><th>Sex</th><th>Date of Birth</th><th>Staff Position</th><th>Staff Salary</th><th>Staff Hired Date</th><th>Staff Bonus Pay</th><th>Staff Supervisor Name</th><th>Branch Number</th></tr>";
    for (let i = 0; i < results.length; i++) {
      html += `<tr><td>${results[i].Staff_number}</td><td>${results[i].Full_name}</td><td>${results[i].sex}</td><td>${results[i].DOB}</td><td>${results[i].Staff_position}</td><td>${results[i].Staff_salary}</td><td>${results[i].Staff_hired_date}</td><td>${results[i].Staff_bonus_pay}</td><td>${results[i].Staff_supervisor_name}</td><td>${results[i].Branch_number}</td></tr>`;
    }
    html += "</table></main></div></body></html>";

    // Send the HTML page to the client
    res.send(html);
  });
});
// --------------------------------testquery----end----------------------
app.listen(3000, () => {
  console.log("Server started on port 3000");
});
